1-50   : Quang - Mỏ quạ
51-100 : Phúc  - Sầu đâu
101-150: T.Anh - Phát tài búp sen
151-200: Qúy   - Chanh
201-250: Thảo  - Tía tô


